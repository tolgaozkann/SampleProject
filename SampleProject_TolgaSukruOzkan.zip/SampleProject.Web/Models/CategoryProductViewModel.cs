﻿namespace SampleProject.Web.Models
{
    public class CategoryProductViewModel
    {
        public List<CategoryViewModel> Categories { get; set; }
        public List<ProductViewModel> Products { get; set; }
    }
}
