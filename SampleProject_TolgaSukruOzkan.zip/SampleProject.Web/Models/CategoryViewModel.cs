﻿namespace SampleProject.Web.Models
{
    public class CategoryViewModel
    {
        public string Name { get; set; }
    }
}
